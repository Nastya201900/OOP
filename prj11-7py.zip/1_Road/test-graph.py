# -*- coding: utf-8 -*-
from simpletk import *

app = TApplication("Дорога")

canvas = TCanvas(app, bg="white")
canvas.align = "client"

app.Run()